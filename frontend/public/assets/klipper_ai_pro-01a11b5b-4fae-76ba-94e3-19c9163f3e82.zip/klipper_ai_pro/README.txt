============================================================
  KLIPPER AI PRO — Auto Short Video Generator
============================================================

Sistem otomatis yang menerima link YouTube / file video,
menganalisis isinya, memilih bagian terbaik dengan Gemini,
menyambungnya, menambah subtitle dinamis & efek pro,
lalu menghasilkan file siap upload ke TikTok / Reels / Shorts.


------------------------------------------------------------
1. PERSYARATAN
------------------------------------------------------------

• Python 3.10 atau lebih baru
• FFmpeg (wajib terinstall di sistem)
• yt-dlp
• OpenAI Whisper
• Google Generative AI (Gemini)

Cek FFmpeg:
  ffmpeg -version

Jika belum ada:
  Ubuntu/Debian : sudo apt update && sudo apt install ffmpeg
  macOS         : brew install ffmpeg
  Windows       : download dari https://ffmpeg.org/download.html


------------------------------------------------------------
2. INSTALASI
------------------------------------------------------------

1) Masuk ke folder proyek:
   cd klipper_ai_pro

2) Buat virtual environment (disarankan):
   python -m venv venv
   source venv/bin/activate          # Linux/macOS
   venv\Scripts\activate             # Windows

3) Install dependencies:
   pip install -r requirements.txt

4) Isi API Key Gemini:
   - Buka https://aistudio.google.com/apikey
   - Buat API key (gratis)
   - Edit file config.py → ganti GEMINI_API_KEY
     atau set environment variable:
       export GEMINI_API_KEY="AIza..."


------------------------------------------------------------
3. CARA PAKAI
------------------------------------------------------------

A. Mode Interaktif (paling mudah)
   python main.py

B. Langsung dari command line
   python main.py "https://www.youtube.com/watch?v=XXXX"

   Dengan opsi:
   python main.py "https://youtube.com/watch?v=XXXX" --duration 30 --ratio 9:16
   python main.py video_lokal.mp4 --local --duration 60
   python main.py "URL" --no-subtitles --whisper small

Opsi yang tersedia:
  --duration / -d     Durasi maksimal (detik). Default: 60
  --ratio / -r        9:16 | 1:1 | 16:9. Default: 9:16
  --no-subtitles      Matikan subtitle
  --no-transition     Matikan transisi fade
  --local             Source adalah file lokal
  --whisper           tiny | base | small | medium | large


------------------------------------------------------------
4. ALUR KERJA
------------------------------------------------------------

FASE 1  Input link / file + pengaturan
FASE 2  Unduh video (yt-dlp) + ekstrak audio
FASE 3  Transkripsi dengan Whisper (teks + timestamp)
FASE 4  Gemini memilih bagian terbaik (Hook → Isi → Penutup)
FASE 5  Validasi waktu & durasi
FASE 6  Potong + sambung klip (FFmpeg)
FASE 7  Crop 9:16, subtitle, transisi, normalisasi audio
FASE 8  Pratinjau (di terminal)
FASE 9  Simpan video + file metadata (judul, caption, hashtag)


------------------------------------------------------------
5. HASIL
------------------------------------------------------------

Semua hasil tersimpan di folder: output/

• video_xxx.mp4          → video siap upload
• metadata_xxx.txt       → judul + caption + hashtag (tinggal copy)
• metadata_xxx.json      → versi JSON
• transcript_xxx.json    → transkrip lengkap (untuk debug)


------------------------------------------------------------
6. STRUKTUR PROYEK
------------------------------------------------------------

klipper_ai_pro/
├── main.py              # Program utama
├── config.py            # Pengaturan & API Key
├── downloader.py        # Unduh video (yt-dlp)
├── transcriber.py       # Whisper → teks + waktu
├── ai_selector.py       # Gemini pilih bagian terbaik
├── editor.py            # Potong, sambung, subtitle, efek
├── exporter.py          # Simpan hasil + metadata
├── requirements.txt
├── README.txt
├── output/              # Hasil video & metadata
└── temp/                # File sementara (otomatis dibuat)


------------------------------------------------------------
7. TIPS
------------------------------------------------------------

• Model Whisper "base" sudah cukup bagus & cepat untuk Bahasa Indonesia.
  Kalau ingin lebih akurat, pakai --whisper small atau medium.

• Gemini 2.0 Flash / 2.5 Flash gratis di aistudio.google.com
  (ada limit request per hari, biasanya cukup untuk testing).

• Untuk video sangat panjang (>1 jam), proses transkripsi bisa lama.
  Disarankan potong dulu atau pakai model tiny/base.

• Subtitle memakai library subtitles filter FFmpeg.
  Pastikan FFmpeg di-compile dengan libass (kebanyakan binary sudah termasuk).


------------------------------------------------------------
8. TROUBLESHOOTING
------------------------------------------------------------

Error "GEMINI_API_KEY belum diisi"
  → Isi di config.py atau export GEMINI_API_KEY=...

Error "openai-whisper belum terinstall"
  → pip install openai-whisper

Error yt-dlp / ffmpeg tidak ditemukan
  → Pastikan sudah terinstall dan ada di PATH

Whisper sangat lambat
  → Pakai model lebih kecil (--whisper tiny) atau install torch GPU


------------------------------------------------------------
Prinsip: Bangun bertahap. Fase 1–6 dulu yang jalan,
baru tambah efek-efek pro. Yang penting berfungsi dulu! 💪

Selamat mencoba!
============================================================
