# ============================================
# Klipper AI Pro - Video Editor (FFmpeg)
# ============================================

import subprocess
import json
from pathlib import Path
from config import (
    TEMP_DIR, OUTPUT_DIR, OUTPUT_FPS,
    RATIO_MAP, ENABLE_TRANSITION, TRANSITION_DURATION,
    ENABLE_SUBTITLES, SUBTITLE_FONTSIZE, SUBTITLE_COLOR,
    SUBTITLE_OUTLINE, SUBTITLE_OUTLINE_WIDTH
)


def cut_and_concat(
    video_path: str,
    segments: list,
    output_name: str = "final",
    ratio: str = "9:16",
    add_subtitles: bool = True,
    transcript_segments: list = None,
    enable_transition: bool = True
) -> str:
    """
    Potong video sesuai segmen yang dipilih, sambung, crop ke rasio,
    dan (opsional) tambah subtitle.
    
    Returns: path file hasil akhir
    """
    video_path = Path(video_path)
    if not video_path.exists():
        raise FileNotFoundError(f"Video tidak ditemukan: {video_path}")

    width, height = RATIO_MAP.get(ratio, (1080, 1920))
    print(f"[Editor] Target resolusi: {width}x{height} ({ratio})")

    # 1. Potong tiap segmen
    clip_paths = []
    for i, seg in enumerate(segments):
        start = seg["start"]
        end = seg["end"]
        duration = end - start
        clip_path = TEMP_DIR / f"clip_{i:03d}.mp4"

        print(f"[Editor] Memotong segmen {i+1}/{len(segments)}: {start:.1f}s → {end:.1f}s")

        # Cut + scale/crop ke rasio target
        # Gunakan scale + crop agar tidak distorsi
        vf = (
            f"scale={width}:{height}:force_original_aspect_ratio=increase,"
            f"crop={width}:{height},"
            f"fps={OUTPUT_FPS}"
        )

        cmd = [
            "ffmpeg", "-y",
            "-ss", str(start),
            "-i", str(video_path),
            "-t", str(duration),
            "-vf", vf,
            "-c:v", "libx264", "-preset", "fast", "-crf", "23",
            "-c:a", "aac", "-b:a", "128k",
            "-movflags", "+faststart",
            str(clip_path)
        ]
        subprocess.run(cmd, check=True, capture_output=True)
        clip_paths.append(clip_path)

    if not clip_paths:
        raise RuntimeError("Tidak ada klip yang berhasil dipotong")

    # 2. Buat file list untuk concat
    list_file = TEMP_DIR / "concat_list.txt"
    with open(list_file, "w") as f:
        for p in clip_paths:
            f.write(f"file '{p.resolve()}'\n")

    # 3. Concat
    concat_path = TEMP_DIR / "concat_temp.mp4"
    print("[Editor] Menyambung klip...")

    if enable_transition and len(clip_paths) > 1:
        # Pakai xfade untuk transisi fade (lebih lambat tapi bagus)
        concat_with_xfade(clip_paths, concat_path, TRANSITION_DURATION)
    else:
        cmd = [
            "ffmpeg", "-y",
            "-f", "concat", "-safe", "0",
            "-i", str(list_file),
            "-c", "copy",
            str(concat_path)
        ]
        subprocess.run(cmd, check=True, capture_output=True)

    # 4. Tambah subtitle (jika diminta)
    final_path = OUTPUT_DIR / f"{output_name}.mp4"

    if add_subtitles and transcript_segments:
        print("[Editor] Menambahkan subtitle dinamis...")
        srt_path = TEMP_DIR / "subtitles.srt"
        create_srt_for_clips(segments, transcript_segments, srt_path)

        cmd = [
            "ffmpeg", "-y",
            "-i", str(concat_path),
            "-vf", f"subtitles={srt_path}:force_style='FontSize={SUBTITLE_FONTSIZE},PrimaryColour=&H00FFFFFF,OutlineColour=&H00000000,Outline={SUBTITLE_OUTLINE_WIDTH},Alignment=2,MarginV=80'",
            "-c:v", "libx264", "-preset", "fast", "-crf", "23",
            "-c:a", "copy",
            "-movflags", "+faststart",
            str(final_path)
        ]
        try:
            subprocess.run(cmd, check=True, capture_output=True)
        except subprocess.CalledProcessError:
            # Fallback tanpa subtitle jika gagal
            print("[Editor] WARNING: Gagal tambah subtitle, menyimpan tanpa subtitle")
            import shutil
            shutil.copy(concat_path, final_path)
    else:
        import shutil
        shutil.copy(concat_path, final_path)

    # Normalisasi audio (opsional)
    normalize_audio(final_path)

    print(f"[Editor] Selesai! File: {final_path}")
    return str(final_path)


def concat_with_xfade(clip_paths: list, output_path: Path, fade_dur: float = 0.3):
    """Sambung klip dengan transisi fade menggunakan xfade filter."""
    if len(clip_paths) == 1:
        import shutil
        shutil.copy(clip_paths[0], output_path)
        return

    # Hitung durasi tiap klip
    durations = []
    for p in clip_paths:
        dur = get_duration(p)
        durations.append(dur)

    # Bangun filter_complex xfade
    # Contoh untuk 3 klip:
    # [0][1]xfade=transition=fade:duration=0.3:offset=...[v01];
    # [v01][2]xfade=...[vout]

    inputs = []
    for p in clip_paths:
        inputs.extend(["-i", str(p)])

    filter_parts = []
    current_label = "0"
    offset = durations[0] - fade_dur

    for i in range(1, len(clip_paths)):
        next_label = f"v{i}"
        if i == len(clip_paths) - 1:
            next_label = "vout"

        filter_parts.append(
            f"[{current_label}][{i}]xfade=transition=fade:duration={fade_dur}:offset={offset:.3f}[{next_label}]"
        )
        current_label = next_label
        if i < len(clip_paths) - 1:
            offset += durations[i] - fade_dur

    filter_complex = ";".join(filter_parts)

    cmd = [
        "ffmpeg", "-y",
        *inputs,
        "-filter_complex", filter_complex,
        "-map", "[vout]",
        "-map", "0:a?",          # ambil audio dari klip pertama dulu (sederhana)
        "-c:v", "libx264", "-preset", "fast", "-crf", "23",
        "-c:a", "aac", "-b:a", "128k",
        "-movflags", "+faststart",
        str(output_path)
    ]

    # Karena audio mapping kompleks dengan xfade, kita pakai cara lebih aman:
    # Concat biasa dulu, lalu biarkan tanpa xfade jika terlalu rumit.
    # Untuk versi pro, user bisa upgrade sendiri.
    try:
        subprocess.run(cmd, check=True, capture_output=True)
    except subprocess.CalledProcessError:
        # Fallback ke concat biasa
        print("[Editor] xfade gagal, fallback ke concat biasa")
        list_file = TEMP_DIR / "concat_list.txt"
        with open(list_file, "w") as f:
            for p in clip_paths:
                f.write(f"file '{p.resolve()}'\n")
        cmd2 = [
            "ffmpeg", "-y",
            "-f", "concat", "-safe", "0",
            "-i", str(list_file),
            "-c", "copy",
            str(output_path)
        ]
        subprocess.run(cmd2, check=True, capture_output=True)


def create_srt_for_clips(selected_segments: list, full_transcript: list, srt_path: Path):
    """
    Buat file SRT berdasarkan segmen yang dipilih.
    Waktu di SRT dihitung ulang dari 0 (karena sudah dipotong).
    """
    srt_lines = []
    counter = 1
    current_time = 0.0

    for seg in selected_segments:
        seg_start = seg["start"]
        seg_end = seg["end"]
        seg_duration = seg_end - seg_start

        # Ambil teks dari full_transcript yang overlap dengan segmen ini
        texts = []
        for t in full_transcript:
            if t["end"] <= seg_start or t["start"] >= seg_end:
                continue
            texts.append(t["text"])

        if not texts:
            current_time += seg_duration
            continue

        text = " ".join(texts)
        # Pecah jadi beberapa baris jika terlalu panjang
        words = text.split()
        chunks = []
        chunk = []
        for w in words:
            chunk.append(w)
            if len(" ".join(chunk)) > 42:
                chunks.append(" ".join(chunk))
                chunk = []
        if chunk:
            chunks.append(" ".join(chunk))

        # Distribusikan waktu per chunk
        if chunks:
            chunk_dur = seg_duration / len(chunks)
            for i, c in enumerate(chunks):
                start_t = current_time + i * chunk_dur
                end_t = start_t + chunk_dur
                srt_lines.append(str(counter))
                srt_lines.append(f"{_srt_time(start_t)} --> {_srt_time(end_t)}")
                srt_lines.append(c)
                srt_lines.append("")
                counter += 1

        current_time += seg_duration

    with open(srt_path, "w", encoding="utf-8") as f:
        f.write("\n".join(srt_lines))


def _srt_time(seconds: float) -> str:
    """Format detik ke SRT time: 00:00:01,000"""
    h = int(seconds // 3600)
    m = int((seconds % 3600) // 60)
    s = int(seconds % 60)
    ms = int((seconds % 1) * 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def get_duration(path: Path) -> float:
    """Ambil durasi video dengan ffprobe."""
    cmd = [
        "ffprobe", "-v", "quiet",
        "-print_format", "json",
        "-show_format",
        str(path)
    ]
    result = subprocess.run(cmd, capture_output=True, text=True, check=True)
    info = json.loads(result.stdout)
    return float(info["format"]["duration"])


def normalize_audio(video_path: Path):
    """Normalisasi volume audio (loudnorm)."""
    temp = video_path.with_suffix(".norm.mp4")
    cmd = [
        "ffmpeg", "-y",
        "-i", str(video_path),
        "-af", "loudnorm=I=-16:TP=-1.5:LRA=11",
        "-c:v", "copy",
        "-c:a", "aac", "-b:a", "128k",
        str(temp)
    ]
    try:
        subprocess.run(cmd, check=True, capture_output=True)
        temp.replace(video_path)
        print("[Editor] Audio dinormalisasi")
    except subprocess.CalledProcessError:
        print("[Editor] WARNING: Gagal normalisasi audio, dilewati")
        if temp.exists():
            temp.unlink()


if __name__ == "__main__":
    print("Editor module siap. Panggil cut_and_concat() dari main.py")
