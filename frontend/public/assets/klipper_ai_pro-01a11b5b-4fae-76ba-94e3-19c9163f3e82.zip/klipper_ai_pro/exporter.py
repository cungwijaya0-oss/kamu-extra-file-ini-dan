# ============================================
# Klipper AI Pro - Exporter
# ============================================

import json
from pathlib import Path
from datetime import datetime
from config import OUTPUT_DIR


def save_metadata(
    title: str,
    caption: str,
    hashtags: str,
    segments: list,
    video_path: str,
    source_title: str = "",
    duration: float = 0
) -> str:
    """
    Simpan metadata (judul, caption, hashtag, info segmen) ke file teks
    yang mudah di-copy.
    """
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    meta_path = OUTPUT_DIR / f"metadata_{timestamp}.txt"

    content = f"""========================================
KLIPPER AI PRO - HASIL SIAP UPLOAD
========================================
Waktu proses : {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
Sumber       : {source_title}
File video   : {video_path}
Durasi akhir : {duration:.1f} detik

----------------------------------------
JUDUL (copy untuk title)
----------------------------------------
{title}

----------------------------------------
CAPTION (copy untuk deskripsi)
----------------------------------------
{caption}

----------------------------------------
HASHTAG
----------------------------------------
{hashtags}

----------------------------------------
BAGIAN YANG DIPILIH
----------------------------------------
"""
    for i, seg in enumerate(segments, 1):
        content += (
            f"{i}. [{seg['start']:.1f}s - {seg['end']:.1f}s] "
            f"{seg.get('type', 'Isi')} — {seg.get('reason', '')}\n"
        )

    content += "\n========================================\n"
    content += "Silakan upload ke TikTok / Reels / Shorts!\n"
    content += "========================================\n"

    with open(meta_path, "w", encoding="utf-8") as f:
        f.write(content)

    # Juga simpan versi JSON untuk keperluan program
    json_path = OUTPUT_DIR / f"metadata_{timestamp}.json"
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump({
            "title": title,
            "caption": caption,
            "hashtags": hashtags,
            "segments": segments,
            "video_path": video_path,
            "source_title": source_title,
            "duration": duration,
            "created_at": datetime.now().isoformat()
        }, f, ensure_ascii=False, indent=2)

    print(f"[Exporter] Metadata disimpan: {meta_path}")
    return str(meta_path)


def print_final_summary(video_path: str, meta_path: str, title: str, caption: str, hashtags: str):
    """Tampilkan ringkasan di terminal."""
    print("\n" + "=" * 50)
    print("  KLIPPER AI PRO — SELESAI!")
    print("=" * 50)
    print(f"\n📹 Video  : {video_path}")
    print(f"📄 Meta   : {meta_path}")
    print(f"\n📝 Judul  : {title}")
    print(f"\n💬 Caption:\n{caption}")
    print(f"\n🏷️  Tags   : {hashtags}")
    print("\n" + "=" * 50)
    print("Siap di-upload ke TikTok / Instagram Reels / YouTube Shorts!")
    print("=" * 50 + "\n")
