# ============================================
# Klipper AI Pro - Configuration
# ============================================

import os
from pathlib import Path

# --- PATHS ---
BASE_DIR = Path(__file__).parent
OUTPUT_DIR = BASE_DIR / "output"
TEMP_DIR = BASE_DIR / "temp"

# Buat folder jika belum ada
OUTPUT_DIR.mkdir(exist_ok=True)
TEMP_DIR.mkdir(exist_ok=True)

# --- API KEYS (isi sendiri) ---
# Dapatkan di: https://aistudio.google.com/apikey
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "MASUKKAN_API_KEY_GEMINI_KAMU_DISINI")

# Model Gemini (gratis & cepat)
GEMINI_MODEL = "gemini-2.0-flash"  # atau "gemini-2.5-flash" jika sudah tersedia

# --- VIDEO SETTINGS ---
DEFAULT_DURATION = 60          # detik
DEFAULT_RATIO = "9:16"         # TikTok / Reels
OUTPUT_FPS = 30
OUTPUT_WIDTH = 1080
OUTPUT_HEIGHT = 1920

# Mapping rasio
RATIO_MAP = {
    "9:16": (1080, 1920),   # TikTok / Reels / Shorts vertikal
    "1:1":  (1080, 1080),   # Instagram Feed
    "16:9": (1920, 1080),   # YouTube / landscape
}

# --- FITUR DEFAULT ---
ENABLE_SUBTITLES = True
ENABLE_MUSIC = False
ENABLE_INTRO = False
ENABLE_OUTRO = False
ENABLE_TRANSITION = True
TRANSITION_DURATION = 0.3      # detik

# --- SUBTITLE STYLE ---
SUBTITLE_FONT = "Arial"
SUBTITLE_FONTSIZE = 48
SUBTITLE_COLOR = "white"
SUBTITLE_OUTLINE = "black"
SUBTITLE_OUTLINE_WIDTH = 2
SUBTITLE_POSITION = "bottom"   # bottom / center / top

# --- AUDIO ---
AUDIO_NORMALIZE = True
MUSIC_VOLUME = 0.15            # 15% volume musik latar

# --- YT-DLP ---
YTDLP_FORMAT = "bestvideo[height<=1080]+bestaudio/best[height<=1080]"
YTDLP_OUTTMPL = str(TEMP_DIR / "%(id)s.%(ext)s")
