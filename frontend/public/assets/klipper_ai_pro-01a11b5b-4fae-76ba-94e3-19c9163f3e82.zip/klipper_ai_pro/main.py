#!/usr/bin/env python3
# ============================================
# Klipper AI Pro - Main Entry Point
# ============================================
"""
Sistem otomatis yang menerima link/video, menganalisis isinya,
memilih bagian terbaik, menyambungnya, menambah subtitle & efek,
lalu menghasilkan file siap upload ke TikTok/Reels/Shorts.
"""

import argparse
import sys
from pathlib import Path

from config import (
    DEFAULT_DURATION, DEFAULT_RATIO, OUTPUT_DIR,
    ENABLE_SUBTITLES, ENABLE_TRANSITION
)
from downloader import download_video, get_local_video_info
from transcriber import transcribe_audio, segments_to_transcript_text, save_transcript
from ai_selector import select_best_parts
from editor import cut_and_concat, get_duration
from exporter import save_metadata, print_final_summary


def run(
    source: str,
    max_duration: int = DEFAULT_DURATION,
    ratio: str = DEFAULT_RATIO,
    subtitles: bool = ENABLE_SUBTITLES,
    transition: bool = ENABLE_TRANSITION,
    whisper_model: str = "base",
    is_local: bool = False
):
    """
    Alur kerja lengkap FASE 1–9.
    """
    print("\n" + "🎬" * 20)
    print("   KLIPPER AI PRO — Mulai Proses")
    print("🎬" * 20 + "\n")

    # ========== FASE 1 & 2: Unduh / Load ==========
    print("▶ FASE 1–2: Persiapan & Unduh video...")
    if is_local or Path(source).exists():
        info = get_local_video_info(source)
    else:
        info = download_video(source)

    print(f"   Judul sumber : {info['title']}")
    print(f"   Durasi asli  : {info['duration']:.1f}s")
    print(f"   Resolusi     : {info['width']}x{info['height']}")

    # ========== FASE 3: Transkripsi ==========
    print("\n▶ FASE 3: Transkripsi audio (Whisper)...")
    transcript_segments = transcribe_audio(info["audio_path"], model_size=whisper_model)
    transcript_text = segments_to_transcript_text(transcript_segments)

    # Simpan transkrip untuk debugging
    transcript_path = OUTPUT_DIR / f"transcript_{info['video_id']}.json"
    save_transcript(transcript_segments, str(transcript_path))

    if not transcript_segments:
        print("❌ Transkrip kosong. Video mungkin tidak punya suara atau Whisper gagal.")
        sys.exit(1)

    print(f"   Total segmen transkrip: {len(transcript_segments)}")

    # ========== FASE 4: Pilih bagian terbaik (Gemini) ==========
    print("\n▶ FASE 4: Gemini memilih bagian terbaik...")
    selection = select_best_parts(transcript_text, max_duration=max_duration)

    segments = selection["segments"]
    title = selection["title"]
    caption = selection["caption"]
    hashtags = selection["hashtags"]

    if not segments:
        print("❌ Gemini tidak menemukan bagian yang cocok. Coba video lain atau naikkan durasi.")
        sys.exit(1)

    print(f"   Judul yang dihasilkan : {title}")
    print(f"   Jumlah segmen terpilih: {len(segments)}")
    for i, s in enumerate(segments, 1):
        print(f"      {i}. {s['start']:.1f}s–{s['end']:.1f}s [{s['type']}] {s.get('reason', '')[:50]}")

    # ========== FASE 5: Cek kualitas ==========
    print("\n▶ FASE 5: Validasi segmen...")
    total_dur = sum(s["end"] - s["start"] for s in segments)
    print(f"   Total durasi terpilih: {total_dur:.1f}s (batas: {max_duration}s)")
    if total_dur > max_duration + 1:
        print("   ⚠️  Durasi sedikit melebihi, akan dipotong otomatis di editor.")

    # ========== FASE 6 & 7: Potong, sambung, edit ==========
    print("\n▶ FASE 6–7: Memotong, menyambung & menambahkan efek...")
    safe_name = "".join(c if c.isalnum() or c in "-_" else "_" for c in title)[:40]
    output_name = f"{info['video_id']}_{safe_name}"

    final_video = cut_and_concat(
        video_path=info["video_path"],
        segments=segments,
        output_name=output_name,
        ratio=ratio,
        add_subtitles=subtitles,
        transcript_segments=transcript_segments,
        enable_transition=transition
    )

    final_duration = get_duration(Path(final_video))

    # ========== FASE 8 & 9: Simpan hasil ==========
    print("\n▶ FASE 8–9: Menyimpan hasil & metadata...")
    meta_path = save_metadata(
        title=title,
        caption=caption,
        hashtags=hashtags,
        segments=segments,
        video_path=final_video,
        source_title=info["title"],
        duration=final_duration
    )

    print_final_summary(final_video, meta_path, title, caption, hashtags)
    return {
        "video": final_video,
        "metadata": meta_path,
        "title": title,
        "caption": caption,
        "hashtags": hashtags,
        "duration": final_duration
    }


def interactive_mode():
    """Mode interaktif sederhana di terminal."""
    print("\n" + "=" * 50)
    print("   KLIPPER AI PRO — Mode Interaktif")
    print("=" * 50)

    source = input("\nMasukkan link YouTube atau path file video: ").strip()
    if not source:
        print("Input kosong. Keluar.")
        return

    print("\nPilih durasi maksimal:")
    print("  1. 30 detik")
    print("  2. 60 detik (default)")
    print("  3. 90 detik")
    print("  4. 3 menit (180 detik)")
    choice = input("Pilihan [1-4, Enter=2]: ").strip() or "2"
    duration_map = {"1": 30, "2": 60, "3": 90, "4": 180}
    max_duration = duration_map.get(choice, 60)

    print("\nPilih rasio:")
    print("  1. 9:16 (TikTok / Reels / Shorts) — default")
    print("  2. 1:1  (Instagram Feed)")
    print("  3. 16:9 (YouTube landscape)")
    ratio_choice = input("Pilihan [1-3, Enter=1]: ").strip() or "1"
    ratio_map = {"1": "9:16", "2": "1:1", "3": "16:9"}
    ratio = ratio_map.get(ratio_choice, "9:16")

    sub_input = input("\nAktifkan subtitle? [Y/n]: ").strip().lower()
    subtitles = sub_input not in ("n", "no", "tidak")

    print("\nRingkasan pengaturan:")
    print(f"  Sumber   : {source}")
    print(f"  Durasi   : {max_duration}s")
    print(f"  Rasio    : {ratio}")
    print(f"  Subtitle : {'Aktif' if subtitles else 'Mati'}")

    confirm = input("\nLanjutkan? [Y/n]: ").strip().lower()
    if confirm in ("n", "no", "tidak"):
        print("Dibatalkan.")
        return

    is_local = Path(source).exists()
    run(
        source=source,
        max_duration=max_duration,
        ratio=ratio,
        subtitles=subtitles,
        is_local=is_local
    )


def main():
    parser = argparse.ArgumentParser(
        description="Klipper AI Pro — Auto Short Video Generator",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Contoh pemakaian:
  python main.py "https://youtube.com/watch?v=xxxx"
  python main.py "https://youtube.com/watch?v=xxxx" --duration 30 --ratio 9:16
  python main.py video_lokal.mp4 --local --duration 60
  python main.py   # mode interaktif
        """
    )
    parser.add_argument("source", nargs="?", help="Link YouTube atau path file video")
    parser.add_argument("--duration", "-d", type=int, default=DEFAULT_DURATION,
                        help=f"Durasi maksimal dalam detik (default: {DEFAULT_DURATION})")
    parser.add_argument("--ratio", "-r", default=DEFAULT_RATIO,
                        choices=["9:16", "1:1", "16:9"],
                        help=f"Rasio output (default: {DEFAULT_RATIO})")
    parser.add_argument("--no-subtitles", action="store_true", help="Matikan subtitle")
    parser.add_argument("--no-transition", action="store_true", help="Matikan transisi fade")
    parser.add_argument("--local", action="store_true", help="Source adalah file lokal")
    parser.add_argument("--whisper", default="base",
                        choices=["tiny", "base", "small", "medium", "large"],
                        help="Ukuran model Whisper (default: base)")

    args = parser.parse_args()

    if not args.source:
        interactive_mode()
        return

    run(
        source=args.source,
        max_duration=args.duration,
        ratio=args.ratio,
        subtitles=not args.no_subtitles,
        transition=not args.no_transition,
        whisper_model=args.whisper,
        is_local=args.local
    )


if __name__ == "__main__":
    main()
