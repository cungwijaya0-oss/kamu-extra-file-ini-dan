# ============================================
# Klipper AI Pro - Video Downloader
# ============================================

import os
import subprocess
import json
from pathlib import Path
from config import TEMP_DIR, YTDLP_FORMAT, YTDLP_OUTTMPL


def download_video(url: str) -> dict:
    """
    Unduh video dari YouTube (atau platform lain yang didukung yt-dlp).
    Mengembalikan dict berisi path video, path audio, info metadata.
    """
    print(f"[Downloader] Mengunduh: {url}")

    # Info video dulu
    info_cmd = [
        "yt-dlp",
        "--dump-json",
        "--no-playlist",
        url
    ]

    try:
        result = subprocess.run(info_cmd, capture_output=True, text=True, check=True)
        info = json.loads(result.stdout)
    except subprocess.CalledProcessError as e:
        raise RuntimeError(f"Gagal mengambil info video: {e.stderr}")
    except json.JSONDecodeError:
        raise RuntimeError("Gagal parse info video dari yt-dlp")

    video_id = info.get("id", "unknown")
    title = info.get("title", "Untitled")
    duration = info.get("duration", 0)
    width = info.get("width", 0)
    height = info.get("height", 0)

    print(f"[Downloader] Judul: {title}")
    print(f"[Downloader] Durasi asli: {duration}s | Resolusi: {width}x{height}")

    # Download video
    out_template = str(TEMP_DIR / f"{video_id}.%(ext)s")
    download_cmd = [
        "yt-dlp",
        "-f", YTDLP_FORMAT,
        "--merge-output-format", "mp4",
        "-o", out_template,
        "--no-playlist",
        "--write-info-json",
        url
    ]

    try:
        subprocess.run(download_cmd, check=True, capture_output=True)
    except subprocess.CalledProcessError as e:
        raise RuntimeError(f"Gagal mengunduh video: {e.stderr.decode() if e.stderr else str(e)}")

    # Cari file hasil download
    video_path = None
    for ext in ["mp4", "mkv", "webm"]:
        candidate = TEMP_DIR / f"{video_id}.{ext}"
        if candidate.exists():
            video_path = candidate
            break

    if not video_path:
        # Cari file apapun yang baru
        files = list(TEMP_DIR.glob(f"{video_id}.*"))
        files = [f for f in files if f.suffix in [".mp4", ".mkv", ".webm", ".mov"]]
        if files:
            video_path = files[0]
        else:
            raise RuntimeError("File video hasil download tidak ditemukan")

    # Ekstrak audio untuk transkripsi
    audio_path = TEMP_DIR / f"{video_id}_audio.wav"
    extract_audio(video_path, audio_path)

    return {
        "video_path": str(video_path),
        "audio_path": str(audio_path),
        "video_id": video_id,
        "title": title,
        "duration": duration,
        "width": width,
        "height": height,
        "url": url
    }


def extract_audio(video_path: Path, audio_path: Path):
    """Ekstrak audio dari video menjadi WAV mono 16kHz (optimal untuk Whisper)."""
    print(f"[Downloader] Mengekstrak audio...")
    cmd = [
        "ffmpeg", "-y",
        "-i", str(video_path),
        "-vn",
        "-acodec", "pcm_s16le",
        "-ar", "16000",
        "-ac", "1",
        str(audio_path)
    ]
    try:
        subprocess.run(cmd, check=True, capture_output=True)
    except subprocess.CalledProcessError as e:
        raise RuntimeError(f"Gagal ekstrak audio: {e.stderr.decode() if e.stderr else str(e)}")


def get_local_video_info(file_path: str) -> dict:
    """Ambil info dari file video lokal."""
    path = Path(file_path)
    if not path.exists():
        raise FileNotFoundError(f"File tidak ditemukan: {file_path}")

    # Pakai ffprobe
    cmd = [
        "ffprobe", "-v", "quiet",
        "-print_format", "json",
        "-show_format", "-show_streams",
        str(path)
    ]
    result = subprocess.run(cmd, capture_output=True, text=True, check=True)
    info = json.loads(result.stdout)

    duration = float(info.get("format", {}).get("duration", 0))
    width, height = 0, 0
    for stream in info.get("streams", []):
        if stream.get("codec_type") == "video":
            width = stream.get("width", 0)
            height = stream.get("height", 0)
            break

    video_id = path.stem
    audio_path = TEMP_DIR / f"{video_id}_audio.wav"
    extract_audio(path, audio_path)

    return {
        "video_path": str(path),
        "audio_path": str(audio_path),
        "video_id": video_id,
        "title": path.stem,
        "duration": duration,
        "width": width,
        "height": height,
        "url": None
    }


if __name__ == "__main__":
    # Test
    import sys
    if len(sys.argv) > 1:
        result = download_video(sys.argv[1])
        print(json.dumps(result, indent=2))
    else:
        print("Usage: python downloader.py <youtube_url>")
