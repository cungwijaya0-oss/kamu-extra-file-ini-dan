# ============================================
# Klipper AI Pro - Transcriber (Whisper)
# ============================================

import json
from pathlib import Path

try:
    import whisper
except ImportError:
    whisper = None


def transcribe_audio(audio_path: str, model_size: str = "base") -> list:
    """
    Transkripsi audio menjadi teks + timestamp.
    
    Returns:
        list of dict: [
            {
                "start": 12.5,
                "end": 18.2,
                "text": "Ini adalah contoh kalimat."
            },
            ...
        ]
    """
    if whisper is None:
        raise ImportError(
            "Library 'openai-whisper' belum terinstall.\n"
            "Jalankan: pip install openai-whisper"
        )

    print(f"[Transcriber] Memuat model Whisper '{model_size}'...")
    model = whisper.load_model(model_size)

    print(f"[Transcriber] Mulai transkripsi: {audio_path}")
    result = model.transcribe(
        audio_path,
        word_timestamps=False,   # segment level sudah cukup
        verbose=False,
        language="id"            # default Indonesia, bisa diganti "en" / None (auto)
    )

    segments = []
    for seg in result.get("segments", []):
        segments.append({
            "start": round(seg["start"], 2),
            "end": round(seg["end"], 2),
            "text": seg["text"].strip()
        })

    print(f"[Transcriber] Selesai. Total segmen: {len(segments)}")
    return segments


def segments_to_transcript_text(segments: list) -> str:
    """Ubah list segmen menjadi teks transkrip yang mudah dibaca Gemini."""
    lines = []
    for s in segments:
        start = _format_time(s["start"])
        end = _format_time(s["end"])
        lines.append(f"[{start} - {end}] {s['text']}")
    return "\n".join(lines)


def _format_time(seconds: float) -> str:
    """Format detik menjadi MM:SS.ms"""
    m = int(seconds // 60)
    s = seconds % 60
    return f"{m:02d}:{s:05.2f}"


def detect_silence_gaps(segments: list, gap_threshold: float = 1.5) -> list:
    """
    Deteksi jeda panjang antar segmen.
    Berguna untuk memotong bagian diam.
    """
    gaps = []
    for i in range(len(segments) - 1):
        gap = segments[i + 1]["start"] - segments[i]["end"]
        if gap >= gap_threshold:
            gaps.append({
                "after_segment": i,
                "start": segments[i]["end"],
                "end": segments[i + 1]["start"],
                "duration": round(gap, 2)
            })
    return gaps


def save_transcript(segments: list, output_path: str):
    """Simpan transkrip ke file JSON."""
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(segments, f, ensure_ascii=False, indent=2)
    print(f"[Transcriber] Transkrip disimpan: {output_path}")


if __name__ == "__main__":
    import sys
    if len(sys.argv) < 2:
        print("Usage: python transcriber.py <audio.wav>")
        sys.exit(1)

    segs = transcribe_audio(sys.argv[1])
    print(segments_to_transcript_text(segs))
