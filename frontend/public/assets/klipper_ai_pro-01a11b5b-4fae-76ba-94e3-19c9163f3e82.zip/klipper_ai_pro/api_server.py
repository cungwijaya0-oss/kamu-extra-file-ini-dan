#!/usr/bin/env python3
# ============================================
# Klipper AI Pro - Simple API Server (opsional)
# ============================================
"""
Jalankan: uvicorn api_server:app --reload --port 8000

Lalu frontend bisa memanggil POST /process
"""

from fastapi import FastAPI, BackgroundTasks, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional
import uuid

from main import run

app = FastAPI(title="Klipper AI Pro API", version="1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Simpan status job sederhana di memory
jobs = {}


class ProcessRequest(BaseModel):
    source: str
    duration: int = 60
    ratio: str = "9:16"
    subtitles: bool = True
    transition: bool = True
    is_local: bool = False


@app.get("/")
def root():
    return {
        "name": "Klipper AI Pro API",
        "status": "running",
        "endpoints": {
            "POST /process": "Mulai proses video",
            "GET /status/{job_id}": "Cek status job"
        }
    }


@app.post("/process")
def process_video(req: ProcessRequest, background_tasks: BackgroundTasks):
    job_id = str(uuid.uuid4())[:8]
    jobs[job_id] = {"status": "queued", "result": None, "error": None}

    def task():
        jobs[job_id]["status"] = "processing"
        try:
            result = run(
                source=req.source,
                max_duration=req.duration,
                ratio=req.ratio,
                subtitles=req.subtitles,
                transition=req.transition,
                is_local=req.is_local
            )
            jobs[job_id]["status"] = "done"
            jobs[job_id]["result"] = result
        except Exception as e:
            jobs[job_id]["status"] = "error"
            jobs[job_id]["error"] = str(e)

    background_tasks.add_task(task)
    return {"job_id": job_id, "message": "Job dimulai"}


@app.get("/status/{job_id}")
def get_status(job_id: str):
    if job_id not in jobs:
        raise HTTPException(status_code=404, detail="Job tidak ditemukan")
    return jobs[job_id]


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
