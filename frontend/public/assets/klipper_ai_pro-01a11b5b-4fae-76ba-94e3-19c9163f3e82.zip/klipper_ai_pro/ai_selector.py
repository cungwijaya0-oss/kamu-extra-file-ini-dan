# ============================================
# Klipper AI Pro - AI Selector (Gemini)
# ============================================

import json
import re
from config import GEMINI_API_KEY, GEMINI_MODEL

try:
    import google.generativeai as genai
except ImportError:
    genai = None


SYSTEM_PROMPT = """Peran: Kamu adalah editor video profesional yang ahli mengubah video panjang menjadi klip pendek yang menarik, viral, dan bermakna.

Tugas:
1. Baca transkrip lengkap beserta waktu tiap bagian
2. Identifikasi HOOK di 3-5 detik pertama — yang paling menarik
3. Pilih poin-poin penting, inspiratif, atau emosional
4. Susun urutan logis: Hook → Isi → Penutup
5. Sesuaikan total durasi dengan batas yang diminta
6. Keluarkan hasil dalam format berikut:

=== DAFTAR BAGIAN ===
- Mulai: [waktu dalam detik], Selesai: [waktu dalam detik], Jenis: [Hook/Isi/Penutup], Alasan: [alasan singkat]

=== JUDUL ===
[judul menarik maksimal 60 karakter]

=== CAPTION ===
[caption singkat & bermakna, 2-4 baris]

=== HASHTAG ===
#tag1 #tag2 #tag3 #tag4 #tag5

Aturan penting:
- Jangan ambil bagian yang terputus atau tidak jelas
- Pastikan alur pembicaraannya tetap masuk akal saat disambung
- Prioritaskan kualitas dibanding jumlah bagian
- Selalu akhiri dengan ajakan bertindak atau pesan bermakna
- Waktu harus dalam format detik (contoh: 12.5), bukan MM:SS
- Total durasi semua bagian tidak boleh melebihi batas yang diminta
"""


def select_best_parts(transcript_text: str, max_duration: int = 60) -> dict:
    """
    Kirim transkrip ke Gemini dan dapatkan bagian terbaik.
    
    Returns:
        {
            "segments": [
                {"start": 12.5, "end": 18.0, "type": "Hook", "reason": "..."},
                ...
            ],
            "title": "...",
            "caption": "...",
            "hashtags": "#tag1 #tag2 ..."
        }
    """
    if genai is None:
        raise ImportError(
            "Library 'google-generativeai' belum terinstall.\n"
            "Jalankan: pip install google-generativeai"
        )

    if not GEMINI_API_KEY or GEMINI_API_KEY.startswith("MASUKKAN"):
        raise ValueError(
            "GEMINI_API_KEY belum diisi!\n"
            "1. Buka https://aistudio.google.com/apikey\n"
            "2. Buat API key\n"
            "3. Isi di config.py atau set environment variable GEMINI_API_KEY"
        )

    genai.configure(api_key=GEMINI_API_KEY)
    model = genai.GenerativeModel(GEMINI_MODEL)

    user_prompt = f"""Batas durasi maksimal: {max_duration} detik.

Berikut transkrip video:

{transcript_text}

Pilih bagian terbaik sesuai instruksi."""

    print(f"[AI Selector] Mengirim ke Gemini ({GEMINI_MODEL})...")
    print(f"[AI Selector] Target durasi: {max_duration}s")

    response = model.generate_content(
        [SYSTEM_PROMPT, user_prompt],
        generation_config={
            "temperature": 0.4,
            "max_output_tokens": 2048,
        }
    )

    raw_text = response.text
    print("[AI Selector] Respons diterima. Parsing...")

    result = parse_gemini_response(raw_text, max_duration)
    return result


def parse_gemini_response(text: str, max_duration: int) -> dict:
    """Parse respons Gemini menjadi struktur data yang rapi."""
    segments = []
    title = ""
    caption = ""
    hashtags = ""

    # === DAFTAR BAGIAN ===
    bagian_match = re.search(
        r"=== DAFTAR BAGIAN ===(.*?)(?==== JUDUL ===|$)",
        text, re.DOTALL | re.IGNORECASE
    )
    if bagian_match:
        block = bagian_match.group(1)
        # Cari setiap baris yang mengandung Mulai:
        for line in block.strip().splitlines():
            line = line.strip()
            if not line or not line.startswith("-"):
                continue
            # Contoh: - Mulai: 12.5, Selesai: 18.0, Jenis: Hook, Alasan: ...
            m = re.search(
                r"Mulai:\s*([\d.]+).*?Selesai:\s*([\d.]+).*?Jenis:\s*(\w+).*?Alasan:\s*(.+)",
                line, re.IGNORECASE
            )
            if m:
                start = float(m.group(1))
                end = float(m.group(2))
                seg_type = m.group(3).strip()
                reason = m.group(4).strip()
                if end > start:
                    segments.append({
                        "start": start,
                        "end": end,
                        "type": seg_type,
                        "reason": reason
                    })

    # === JUDUL ===
    title_match = re.search(
        r"=== JUDUL ===\s*(.+?)(?==== CAPTION ===|$)",
        text, re.DOTALL | re.IGNORECASE
    )
    if title_match:
        title = title_match.group(1).strip().split("\n")[0].strip()

    # === CAPTION ===
    caption_match = re.search(
        r"=== CAPTION ===\s*(.+?)(?==== HASHTAG ===|$)",
        text, re.DOTALL | re.IGNORECASE
    )
    if caption_match:
        caption = caption_match.group(1).strip()

    # === HASHTAG ===
    hashtag_match = re.search(
        r"=== HASHTAG ===\s*(.+?)$",
        text, re.DOTALL | re.IGNORECASE
    )
    if hashtag_match:
        hashtags = hashtag_match.group(1).strip().split("\n")[0].strip()

    # Validasi & potong jika melebihi durasi
    segments = validate_and_trim_segments(segments, max_duration)

    if not segments:
        # Fallback: ambil 3 segmen pertama dari teks mentah (jika parsing gagal)
        print("[AI Selector] WARNING: Parsing gagal, mencoba fallback...")
        segments = _fallback_parse(text, max_duration)

    return {
        "segments": segments,
        "title": title or "Video Menarik",
        "caption": caption or "Tonton sampai habis!",
        "hashtags": hashtags or "#fyp #viral #shorts"
    }


def validate_and_trim_segments(segments: list, max_duration: float) -> list:
    """Pastikan tidak overlapping dan total durasi <= max_duration."""
    if not segments:
        return []

    # Sort by start
    segments = sorted(segments, key=lambda x: x["start"])

    cleaned = []
    total = 0.0
    last_end = -1

    for seg in segments:
        start = seg["start"]
        end = seg["end"]
        duration = end - start

        if duration <= 0:
            continue
        if start < last_end:
            # Overlap → geser start
            start = last_end
            duration = end - start
            if duration <= 0.3:
                continue

        if total + duration > max_duration:
            # Potong sisa
            remaining = max_duration - total
            if remaining < 1.0:
                break
            end = start + remaining
            duration = remaining

        cleaned.append({
            "start": round(start, 2),
            "end": round(end, 2),
            "type": seg.get("type", "Isi"),
            "reason": seg.get("reason", "")
        })
        total += duration
        last_end = end

        if total >= max_duration:
            break

    print(f"[AI Selector] Total durasi terpilih: {round(total, 1)}s dari {len(cleaned)} segmen")
    return cleaned


def _fallback_parse(text: str, max_duration: float) -> list:
    """Fallback sederhana jika format Gemini tidak sesuai."""
    # Coba cari pola angka-angka waktu
    times = re.findall(r"(\d+\.?\d*)\s*[-–]\s*(\d+\.?\d*)", text)
    segments = []
    total = 0.0
    for start_s, end_s in times:
        start, end = float(start_s), float(end_s)
        if end <= start:
            continue
        dur = end - start
        if total + dur > max_duration:
            break
        segments.append({
            "start": start,
            "end": end,
            "type": "Isi",
            "reason": "fallback"
        })
        total += dur
    return segments


if __name__ == "__main__":
    # Test dengan dummy transcript
    dummy = """
[00:00.00 - 00:05.20] Halo semuanya, hari ini saya mau bahas 5 kebiasaan yang mengubah hidup saya.
[00:05.20 - 00:12.50] Yang pertama adalah bangun lebih pagi. Ini bikin saya lebih produktif.
[00:12.50 - 00:20.00] Kedua, olahraga ringan setiap hari. Badan jadi lebih sehat dan pikiran jernih.
[00:20.00 - 00:28.00] Ketiga, membaca minimal 10 halaman buku. Ilmu baru selalu datang.
[00:28.00 - 00:35.00] Keempat, menulis jurnal sebelum tidur. Refleksi diri sangat penting.
[00:35.00 - 00:42.00] Dan terakhir, bersyukur setiap hari. Ini yang paling mengubah mindset saya.
[00:42.00 - 00:48.00] Coba terapkan satu saja hari ini, dan lihat perubahannya.
"""
    try:
        result = select_best_parts(dummy, max_duration=30)
        print(json.dumps(result, indent=2, ensure_ascii=False))
    except Exception as e:
        print(f"Error (normal jika API key belum diisi): {e}")
